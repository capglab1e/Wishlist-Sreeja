package com.cg.capstore.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.capstore.dao.WishlistDao;
import com.cg.capstore.dto.Wishlist;

@Service
@Transactional
public class WishlistServiceImpl implements WishlistService{

	@Autowired
	WishlistDao dao;
	
	@Override
	public List<Wishlist> getAll() {
		return dao.getAll();
	}

	@Override
	public List<Wishlist> delete(String user_Id) {
		
		return dao.delete(user_Id);
	}

	@Override
	public Wishlist add(Wishlist Wishlist) {
		// TODO Auto-generated method stub
		return dao.add(Wishlist);
	}

	@Override
	public Wishlist getWishlistDetails(String user_Id) {
		// TODO Auto-generated method stub
		return dao.getWishlistDetails(user_Id);
	}

	@Override
	public String update(Wishlist Wishlist) {
		// TODO Auto-generated method stub
		return dao.update(Wishlist);
	}

	

}
