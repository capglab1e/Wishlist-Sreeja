package com.cg.capstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Wishlist;


@Repository("dao")
public class WishlistDaoImpl implements WishlistDao {

	@PersistenceContext
	EntityManager entitymanager;
	
	public EntityManager getEntitymanager() {
		return entitymanager;
	}

	public void setEntitymanager(EntityManager entitymanager) {
		this.entitymanager = entitymanager;
	}
	
	@Override
	public List<Wishlist> getAll() {
		System.out.println("In Dao class method....");
		String str = "select Wishlist1 from Wishlist Wishlist1";
		TypedQuery<Wishlist> query = entitymanager.createQuery(str,Wishlist.class);
		return query.getResultList();
	}

	@Override
	public List<Wishlist> delete(String user_Id) {
		// TODO Auto-generated method stub
		Wishlist Wishlist = getWishlistDetails(user_Id);
		entitymanager.remove(Wishlist);
		return getAll();
	}

	@Override
	public Wishlist add(Wishlist Wishlist) {
		// TODO Auto-generated method stub
		entitymanager.persist(Wishlist);
		entitymanager.flush();
		return Wishlist;
	}
	@Override
	public Wishlist getWishlistDetails(String user_Id) {
		// TODO Auto-generated method stub
		Wishlist Wishlist = entitymanager.find(Wishlist.class, user_Id);
		return Wishlist;

	}

	@Override
	public String update(Wishlist Wishlist) {
		// TODO Auto-generated method stub
		entitymanager.merge(Wishlist);
		return Wishlist.getUser_Id();
	}

}
