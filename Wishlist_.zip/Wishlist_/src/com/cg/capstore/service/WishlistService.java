package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.dto.Wishlist;

public interface WishlistService {
	public List<Wishlist> getAll();
	public Wishlist getWishlistDetails(String user_Id);
	public List<Wishlist> delete(String user_Id);
	public Wishlist add(Wishlist wishlist);
	public String update(Wishlist wishlist);
}
