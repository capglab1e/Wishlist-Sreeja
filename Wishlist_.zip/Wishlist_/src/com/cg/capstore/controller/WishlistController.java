package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capstore.dto.Wishlist;
import com.cg.capstore.service.WishlistService;



@Controller
public class WishlistController {

	@Autowired
	WishlistService service;

	public WishlistService getService() {
		return service;
	}

	public void setService(WishlistService service) {
		this.service = service;
	}

	@RequestMapping("getWishlistlist.obj")
	public ModelAndView showWishlistList(Model model){

		//To fetch data from database
		List<Wishlist> list = service.getAll();
		return new ModelAndView("home","list",list);	
	}

	@RequestMapping("add.obj")
	public String addToWishlist(@ModelAttribute("my") Wishlist Wishlist){
		return "addform";
	}

	@RequestMapping("added.obj")
	public String addedToWishlist(@ModelAttribute("my") Wishlist Wishlist){
		Wishlist c= service.add(Wishlist);
		System.out.println(c);
		return "addsuccess";
	}

	@RequestMapping("delete.obj")
	public String deleteWishlist(@ModelAttribute("my") Wishlist Wishlist){
		return "deleteform";
	}
	@RequestMapping("deleted.obj")
	public String deleteFromWishlist(@ModelAttribute("my") Wishlist Wishlist){
		System.out.println(Wishlist.getUser_Id());
		service.delete(Wishlist.getUser_Id());
		return "deletesuccess";
	}

	@RequestMapping("increment")
	public String incremen(@RequestParam("Wishlistid") String user_Id,Model model){

		Wishlist Wishlist = service.getWishlistDetails(user_Id);
		System.out.println(Wishlist);
		int quan=Wishlist.getQuantity();
		int price=Wishlist.getPrice();
		int newPrice = price/quan;
		quan=quan+1;
		price=newPrice*quan;
		System.out.println(quan);
		System.out.println(price);
		Wishlist.setQuantity(quan);
		Wishlist.setPrice(price);
		service.update(Wishlist);
		List<Wishlist> list = service.getAll();
		System.out.println(list);
		model.addAttribute("list", list);
		return "home";
	}
	@RequestMapping("decrement")
	public String decrement(@RequestParam("Wishlistid") String user_Id,Model model){

		Wishlist Wishlist = service.getWishlistDetails(user_Id);
		System.out.println(Wishlist);
		int quan=Wishlist.getQuantity();
		if(quan>1)
		{

			int price=Wishlist.getPrice();
			int newPrice = price/quan;
			quan=quan-1;
			price=newPrice*quan;
			System.out.println(quan);
			System.out.println(price);
			Wishlist.setQuantity(quan);
			Wishlist.setPrice(price);
			service.update(Wishlist);
			List<Wishlist> list = service.getAll();
			System.out.println(list);
			model.addAttribute("list", list);
		}
		else
			service.delete(user_Id);
		List<Wishlist> list = service.getAll();
		System.out.println(list);
		model.addAttribute("list", list);
		return "home";
	}
}
