package com.cg.capstore.dao;

import java.util.List;
import com.cg.capstore.dto.Wishlist;

public interface WishlistDao {
	public List<Wishlist> getAll();
	public Wishlist getWishlistDetails(String user_Id);
	public List<Wishlist> delete(String user_Id);
	public Wishlist add(Wishlist Wishlist);
	public String update(Wishlist Wishlist);
}

